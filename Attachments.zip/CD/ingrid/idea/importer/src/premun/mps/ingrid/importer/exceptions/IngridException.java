package premun.mps.ingrid.importer.exceptions;

public class IngridException extends RuntimeException {
    public IngridException(String message) {
        super(message);
    }
}
