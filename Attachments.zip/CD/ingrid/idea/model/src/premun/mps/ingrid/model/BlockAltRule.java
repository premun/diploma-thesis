package premun.mps.ingrid.model;

public class BlockAltRule extends Rule {
    public BlockAltRule() {
        super("|");
    }
}
