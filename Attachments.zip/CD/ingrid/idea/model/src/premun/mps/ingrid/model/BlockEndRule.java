package premun.mps.ingrid.model;

public class BlockEndRule extends Rule {
    public BlockEndRule() {
        super(")");
    }
}
