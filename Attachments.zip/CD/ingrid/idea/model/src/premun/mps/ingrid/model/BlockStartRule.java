package premun.mps.ingrid.model;

public class BlockStartRule extends Rule {
    public BlockStartRule() {
        super("(");
    }
}
