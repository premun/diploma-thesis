package premun.mps.ingrid.parser.exception;

public class IngridParserException extends RuntimeException {
    public IngridParserException(String message) {
        super(message);
    }
}
