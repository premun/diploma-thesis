package premun.mps.ingrid.parser.exception;

public class UnresolvableRuleException extends IngridParserException {
    public UnresolvableRuleException(String message) {
        super(message);
    }
}
