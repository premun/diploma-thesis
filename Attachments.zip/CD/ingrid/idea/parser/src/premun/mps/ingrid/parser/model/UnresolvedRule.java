package premun.mps.ingrid.parser.model;

import premun.mps.ingrid.model.*;

public abstract class UnresolvedRule extends Rule {
    public UnresolvedRule(String name) {
        super(name);
    }
}
