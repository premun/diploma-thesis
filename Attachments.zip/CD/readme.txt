This disk is an attachment to a master thesis "Grammar to JetBrains MPS Convertor".

More information can be found inside the PDF of the thesis.

Contents of the disk:
    examples/ .......... MPS project containing imports from Chapter 8
    grammars/ ...................... example adjusted ANTLRv4 grammars
    ingrid/ ................. files of the software part of the thesis
        idea/ ...................... IntelliJ IDEA project (Java part)
        lib/ ................. libraries needed for plugin compilation
        mps/ ............................... MPS project of the plugin
        latex/ ...................... source LaTeX files of the thesis
    Grammar to JetBrains MPS convertor.pdf ......... the thesis in PDF
    premun.mps.ingrid.zip ........................ compiled MPS plugin
    readme.txt ..................................... info about the CD


Setting up projects
-------------------
To setup the Ingrid MPS project from this CD disk, you need to set the INGRID_HOME
path variable to point to the CD/ingrid directory.

To setup the Ingrid IDEA project, you first need to open the MPS project and compile
the premun.mps.ingrid.library solution. Then, you can open the IDEA project with no
other setup needed.
